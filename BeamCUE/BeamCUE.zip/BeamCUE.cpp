#include <iostream>
#include "BeamCUE.h";
#include <WS2tcpip.h>
#pragma comment (lib, "ws2_32.lib")
#include <bitset>
// disable deprecation
#pragma warning(disable: 4996)



using namespace std;



int main() {
	// Initialise Winsock
	WSADATA data;
	WORD version = MAKEWORD(2, 2);

	// Start Winsock
	int wsOk = WSAStartup(version, &data);
	if (wsOk != 0)
	{
		// Broken, exit
		cout << "Can't start Winsock! " << wsOk;
		return 0;
	}

	// Create a hint structure for the server
	SOCKET in = socket(AF_INET, SOCK_DGRAM, 0);
	sockaddr_in serverHint;
	serverHint.sin_addr.S_un.S_addr = ADDR_ANY;
	serverHint.sin_family = AF_INET;
	serverHint.sin_port = htons(4444);

	// Bind the socket to an IP address and port
	if (bind(in, (sockaddr*)&serverHint, sizeof(serverHint)) == SOCKET_ERROR)
	{
		cout << "Unable to bind socket! " << WSAGetLastError() << endl;
		return 0;
	}

	// Create a sockaddr_in structure for the client
	sockaddr_in client;
	int clientLength = sizeof(client);
	

	// while loop
	while (true) {
		// Wait for message
		char buf[265];
		ZeroMemory(buf, 265);
		int bytesIn = recvfrom(in, buf, 265, 0, (sockaddr*)&client, &clientLength);
		if (bytesIn == SOCKET_ERROR)
		{
			cout << "Error receiving from client " << WSAGetLastError() << endl;
			continue;
		}

		// Display message and client info
		char clientIp[256];
		ZeroMemory(clientIp, 256);

		// struct I4sHccfffffffIIfffcci in python:
		// make unsigned int called time
		unsigned int time;
		// make 4 byte char called carName
		char carName[4];
		// make pad byte called pad1
		char pad1;
		// make unsiogned short called info
		unsigned short info;
		// make 2 unsigned char called gear AND playerID
		unsigned char gear, playerID;
		// make 7 floats called speed, rpm, turbo, engineTemp, fuel, oilPressure, oilTemp
		float speed, rpm, turbo, engineTemp, fuel, oilPressure, oilTemp;
		// make 2 unsigned ints called dashLights and showLights
		unsigned int dashLights, showLights;
		// make 3 floats called throttle, brake, clutch
		float throttle, brake, clutch;
		// make 16 byte char called display1
		char display1[16];
		// make pad byte called pad2
		char pad2;
		// make 16 byte char called display2
		char display2[16];
		
		// "unpack" the data
		memcpy(&time, buf, 4);
		memcpy(&carName, buf + 4, 4);
		memcpy(&pad1, buf + 7, 1);
		memcpy(&info, buf + 8, 2);
		memcpy(&gear, buf + 10, 1);
		memcpy(&playerID, buf + 11, 1);
		memcpy(&speed, buf + 12, 4);
		memcpy(&rpm, buf + 16, 4);
		memcpy(&turbo, buf + 20, 4);
		memcpy(&engineTemp, buf + 24, 4);
		memcpy(&fuel, buf + 28, 4);
		memcpy(&oilPressure, buf + 32, 4);
		memcpy(&oilTemp, buf + 36, 4);
		memcpy(&dashLights, buf + 40, 4);
		memcpy(&showLights, buf + 44, 4);
		memcpy(&throttle, buf + 48, 4);
		memcpy(&brake, buf + 52, 4);
		memcpy(&clutch, buf + 56, 4);
		memcpy(&display1, buf + 60, 15);
		memcpy(&pad2, buf + 75, 1);
		memcpy(&display2, buf + 76, 15);
		
		// display the data
		cout << "Time: " << time << endl;
		// terminate carName to null for cout
		carName[3] = '\0';
		cout << "Car Name: " << carName << endl;
		// need to cast any chars to int for previewing as int, otherwise it will show ascii
		cout << "Info: " << (int)info << endl;
		cout << "Gear: " << (int)gear << endl;
		cout << "Player ID: " << (int)playerID << endl;
		cout << "Speed: " << speed << endl;
		cout << "RPM: " << rpm << endl;
		cout << "Turbo: " << turbo << endl;
		cout << "Engine Temp: " << engineTemp << endl;
		cout << "Fuel: " << fuel << endl;
		cout << "Oil Pressure: " << oilPressure << endl;
		cout << "Oil Temp: " << oilTemp << endl;
		cout << "Dash Lights: " << dashLights << endl;
		cout << "Show Lights: " << showLights << endl;
		cout << "Throttle: " << throttle << endl;
		cout << "Brake: " << brake << endl;
		cout << "Clutch: " << clutch << endl;
		// show raw bits from display 1 and display 2
		cout << "Display 1: ";
		for (int i = 0; i < 16; i++) {
			cout << (int)display1[i] << " ";
		}
		cout << endl;
		cout << "Display 2: ";
		for (int i = 0; i < 16; i++) {
			cout << (int)display2[i] << " ";
		}
		cout << endl;
		//updateColours((int)gear, rpm);
	}

	closesocket(in);
	WSACleanup();
}
